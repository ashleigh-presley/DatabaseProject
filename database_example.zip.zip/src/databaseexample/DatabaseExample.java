package databaseexample;

import java.sql.*;
import java.util.Scanner;

/**
 *
 * @author Brionne
 */
public class DatabaseExample {
    private static Scanner sc;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        initPrompt();
    }
    
    public static void initPrompt(){
        System.out.println("Enter M to see all menu options");
        String in;
        sc = new Scanner(System.in);
        do{
            System.out.print("> ");
            in = sc.nextLine();
            switch(in.toUpperCase()){
                case "1":
                    selectAll();
                    break;
                case "2":
                    selectOnePrompt();
                    break;
                case "3":
                    insertTopicPrompt();
                    break;
                case "4":
                    insertThingPrompt();
                    break;
                case "M":
                    displayMenu();
                    break;
                case "EXIT":
                case "X":
                    in="X";
                    break;
                default :
                    System.out.println("Invalid option selected");
                    break;
            }
        } while(!"X".equals(in));
    }
    
    public static void displayMenu(){
        System.out.println("1 - Display All");
        System.out.println("2 - Find");
        System.out.println("3 - Insert");
        System.out.println("M - Display Menu");
        System.out.println("X - Exit");
    }

    public static void selectAll() {
        try (Connection conn = connectToDB()) {
            try (Statement stmt = conn.createStatement()) {
                ResultSet rs = stmt.executeQuery("SELECT * FROM Abstract_Topic_Project.topics");
                while(rs.next()){
                    System.out.printf("%d. %s \n", rs.getInt("topicID"), rs.getString("name"));
                }
            }

        } catch (SQLException ex) {
            System.out.print(ex);
        }
    }
    
    public static void selectOnePrompt(){
        System.out.print("> Enter id: ");
        selectOne(sc.nextLine().trim());
    }
    public static void selectOne(String id) {
        try (Connection conn = connectToDB()) {
            try (PreparedStatement stmt = conn.prepareStatement("SELECT tpc.*, thn.name as thingName FROM Abstract_Topic_Project.topics tpc LEFT JOIN Abstract_Topic_Project.things thn ON tpc.topicID=thn.topicID  WHERE tpc.topicID = ?")) {
                stmt.setString(1, id);
                ResultSet rs = stmt.executeQuery();
                
                if(rs.next()){
                    System.out.printf("%d. %s - %s \n", rs.getInt("topicID"), rs.getString("name"), rs.getString("createdAt"));
                    do{
                        System.out.printf("\t %s \n", rs.getString("thingName"));
                    }while(rs.next());
                }else{
                    System.out.printf("Nothing found with id %s \n", id);
                }
            }

        } catch (SQLException ex) {
            System.out.print(ex);
        }
    }
    
    public static void insertTopicPrompt(){
        System.out.print("> New: ");
        insertTopic(sc.nextLine().trim());
    }
        
    public static void insertTopic(String topicName) {
        try (Connection conn = connectToDB()) {
            try (PreparedStatement stmt = conn.prepareStatement("INSERT INTO Abstract_Topic_Project.topics (`name`) VALUES (?)", Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, topicName);
                int affectedRows = stmt.executeUpdate();                
                if(affectedRows > 0){
                    ResultSet rs = stmt.getGeneratedKeys();
                    rs.next();
                    System.out.printf("New Key %d \n", rs.getInt(1));
                }else{
                    System.out.println("Unable to create at this time");
                }
            }

        } catch (SQLException ex) {
            System.out.print(ex);
        }
    }
    
    public static void insertThingPrompt(){
        System.out.print("> Topic: ");
        String topicID = sc.nextLine().trim();
        System.out.print("> Thing Name: ");
        String name = sc.nextLine().trim();
        insertThing(topicID, name);
    }
    
    public static void insertThing(String topicID, String name) {
        try (Connection conn = connectToDB()) {
            try (PreparedStatement stmt = conn.prepareStatement("INSERT INTO Abstract_Topic_Project.things (`topicID`, `name`) VALUES (?, ?)", Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(2, name);
                stmt.setString(1, topicID);
                int affectedRows = stmt.executeUpdate();                
                if(affectedRows > 0){
                    ResultSet rs = stmt.getGeneratedKeys();
                    rs.next();
                    System.out.printf("New Key %d \n", rs.getInt(1));
                }else{
                    System.out.println("Unable to create at this time");
                }
            }

        } catch (SQLException ex) {
            System.out.print(ex);
        }
    }

    public static Connection connectToDB() throws SQLException {
        return DriverManager.getConnection(
                "jdbc:mysql://cs3350.cdgm0mqfoggp.us-east-1.rds.amazonaws.com", "demo_user", "reallyweakpassword!");

    }

}
